#include <iostream>
#include <cstdlib>
#include <time.h>
int main() {

char ans;
do
{
  time_t seconds;
  time(&seconds);
  srand((unsigned int) seconds);
  int rando = rand() % 10;
  char quest[500];
  std::cout << "       _.a$$$$$a._\n"
"     ,$$$$$$$$$$$$$.\n"
"   ,$$$$$$$$$$$$$$$$$.\n"
"  d$$$$$$$$$$$$$$$$$$$b\n"
" d$$$$$$$$~'\"`~$$$$$$$$b\n"
"($$$$$$$p   _   q$$$$$$$)\n"
"$$$$$$$$   (_)   $$$$$$$$\n"
"$$$$$$$$   (_)   $$$$$$$$\n"
"($$$$$$$b       d$$$$$$$)\n"
" q$$$$$$$$a._.a$$$$$$$$p\n"
"  q$$$$$$$$$$$$$$$$$$$p\n"
"   `$$$$$$$$$$$$$$$$$'\n"
"     `$$$$$$$$$$$$$'\n"
"       `~$$$$$$$~' \n \n";

std::cout << "Welcome to Daniel's 8-ball program!  To play, please enter a yes or no question! \n \n";
std::cin >> quest;
std::cout << '\n';
if(rando == 0){
  std::cout << "Yes";
}
if(rando == 1){
  std::cout << "No";
}
if(rando == 2){
  std::cout << "Maybe";
}
if(rando == 3){
  std::cout << "I wouldn't count on it.";
}
if(rando == 4){
  std::cout << "Definitely.";
}
if(rando == 5){
  std::cout << "Odds say likely.";
}
if(rando == 6){
  std::cout << "Ask again later.";
}
if(rando == 7){
  std::cout << "Fatal Error 493: uninitialized variable 'answer'";
}
if(rando == 8){
  std::cout << "Not a chance.";
}
if(rando == 9){
  std::cout << "Don't know";
}
std::cout << " \n \n Ask another question? (Y/N) \n";
std::cin >> ans;
} while (ans =='y' || ans == 'Y');
}